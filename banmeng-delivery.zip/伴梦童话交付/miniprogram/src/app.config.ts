export default {
  pages: [
    'pages/welcome/index',
    'pages/home/index',
    'pages/studio/index',
    'pages/my/index',
    'pages/wizard/index',
    'pages/story/index',
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#ffffff',
    navigationBarTitleText: '伴梦童话',
    navigationBarTextStyle: 'black',
  },
  tabBar: {
    color: '#999999',
    selectedColor: '#18181b',
    backgroundColor: '#ffffff',
    borderStyle: 'black',
    list: [
      { pagePath: 'pages/home/index', text: '首页' },
      { pagePath: 'pages/studio/index', text: '故事屋' },
      { pagePath: 'pages/my/index', text: '我的' },
    ],
  },
}
