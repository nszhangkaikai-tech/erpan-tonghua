import Taro from '@tarojs/taro'

/**
 * 统一请求封装：替代原型中的全局 fetch（小程序无全局 fetch）。
 * - 小程序请求必须走 Taro.request（底层 wx.request）。
 * - baseURL 注意：微信开发者工具模拟器可用 localhost；真机需用开发机 LAN IP 或线上域名，
 *   且需在 mp 后台「开发管理-服务器域名」配置 request 合法域名（或本地勾选"不校验合法域名"）。
 * - 预留 wx.login 后的 token 注入（阶段3 登录态打通后启用）。
 */
const BASE_URL = process.env.TARO_API_BASE || 'http://localhost:3000'
export const API_BASE = BASE_URL

// 预留：阶段3 微信登录后写入本地存储的自定义登录态
function getToken(): string {
  return Taro.getStorageSync('bm_token') || ''
}

export interface RequestOptions {
  url: string
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'OPTIONS'
  data?: Record<string, any> | string | ArrayBuffer
  header?: Record<string, string>
}

export interface ApiResponse<T = any> {
  code: number
  message?: string
  data?: T
  [key: string]: any
}

const request = <T = any>(options: RequestOptions): Promise<T> => {
  const token = getToken()
  const header: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.header || {}),
  }
  if (token) header['Authorization'] = `Bearer ${token}`

  return new Promise<T>((resolve, reject) => {
    Taro.request({
      url: `${BASE_URL}${options.url}`,
      method: options.method || 'GET',
      data: options.data,
      header,
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data as T)
        } else if (res.statusCode === 401) {
          // 预留：登录态失效 → 跳转微信登录（阶段3）
          Taro.removeStorageSync('bm_token')
          reject({ statusCode: res.statusCode, data: res.data })
        } else {
          reject({ statusCode: res.statusCode, data: res.data })
        }
      },
      fail: (err) => {
        reject(err)
      },
    })
  })
}

export default request
export { request }
