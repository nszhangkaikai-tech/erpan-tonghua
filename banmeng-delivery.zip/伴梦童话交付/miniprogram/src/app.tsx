import { PropsWithChildren } from 'react'
import { useLaunch } from '@tarojs/taro'

import './app.scss'

function App({ children }: PropsWithChildren) {
  useLaunch(() => {
    console.log('App launched.')
  })

  // 打样阶段：保留全局样式入口，后续可在此做微信登录态初始化（阶段3）
  return children
}

export default App
