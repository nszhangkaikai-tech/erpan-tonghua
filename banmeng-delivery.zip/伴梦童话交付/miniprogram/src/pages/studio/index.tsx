import { View, Text, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import './index.scss'

export default function Studio() {
  const goWizard = () => {
    Taro.navigateTo({ url: '/pages/wizard/index' })
  }

  return (
    <View className='studio'>
      <Text className='studio__title'>故事屋</Text>
      <Text className='studio__hint'>
        此处集合 AI 故事定制能力：主题 / 教育目标 / 角色 / 时长 → StepFun 生成文本与封面 → 声音复刻配音。
      </Text>
      <Button className='studio__cta' onClick={goWizard}>
        开始定制故事
      </Button>
    </View>
  )
}
