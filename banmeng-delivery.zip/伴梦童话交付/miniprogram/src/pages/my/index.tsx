import { View, Text } from '@tarojs/components'
import './index.scss'

export default function My() {
  return (
    <View className='my'>
      <Text className='my__title'>我的</Text>
      <Text className='my__hint'>
        此处将承载：孩子资料、声音克隆管理、故事宝库、通知中心、兑换激活码、邀请好友、关于页。
        登录态将在阶段3由 localStorage 假登录替换为微信一键授权 + 手机号绑定。
      </Text>
    </View>
  )
}
