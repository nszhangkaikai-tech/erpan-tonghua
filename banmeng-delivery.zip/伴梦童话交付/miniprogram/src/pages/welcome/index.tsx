import { useState } from 'react'
import { View, Text, Button } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import './index.scss'

type Step = 'auth' | 'phone' | 'done'

export default function Welcome() {
  const [step, setStep] = useState<Step>('auth')
  const [wxCode, setWxCode] = useState('')

  // 已登录则直接进首页（替换原型 localStorage 假登录为微信登录态判断）
  useDidShow(() => {
    if (Taro.getStorageSync('bm_logged_in')) {
      Taro.reLaunch({ url: '/pages/home/index' })
    }
  })

  // 步骤1：微信一键授权，换取 login code（真实环境后端用 code 换 openid/session）
  const handleWechatAuth = async () => {
    try {
      const res = await Taro.login()
      setWxCode(res.code || '')
      // 阶段3：此处应 POST /api/auth/wx-login { code } 换自定义登录态；
      // 当前后端 Express 尚未开通该端点，先本地标记，待 CloudBase 云函数接入。
      setStep('phone')
    } catch (e) {
      Taro.showToast({ title: '授权失败', icon: 'none' })
    }
  }

  // 步骤2：绑定手机号（真实环境 e.detail.code 由后端 auth.getPhoneNumber 解密）
  const handleGetPhone = (e: any) => {
    const phoneCode = e?.detail?.code
    if (!phoneCode) {
      Taro.showToast({ title: '请允许手机号授权', icon: 'none' })
      return
    }
    Taro.setStorageSync('bm_logged_in', true)
    Taro.setStorageSync('bm_phone_bound', true)
    Taro.setStorageSync('bm_wx_code', wxCode)
    Taro.reLaunch({ url: '/pages/home/index' })
  }

  // 游客体验：DEV/无 AppID 场景可跳过，便于开发者工具预览
  const handleTourist = () => {
    Taro.setStorageSync('bm_logged_in', true)
    Taro.setStorageSync('bm_tourist', true)
    Taro.reLaunch({ url: '/pages/home/index' })
  }

  return (
    <View className='welcome'>
      <View className='welcome__brand'>
        <Text className='welcome__logo'>伴</Text>
        <Text className='welcome__name'>伴梦童话</Text>
        <Text className='welcome__slogan'>用孩子的声音，讲专属的晚安故事</Text>
      </View>

      <View className='welcome__panel'>
        {step === 'auth' && (
          <View>
            <Button className='welcome__btn' onClick={handleWechatAuth}>
              微信一键授权
            </Button>
            <Text className='welcome__tip'>授权用于生成你的专属小程序身份</Text>
          </View>
        )}

        {step === 'phone' && (
          <View>
            <Button className='welcome__btn' openType='getPhoneNumber' onGetPhoneNumber={handleGetPhone}>
              绑定手机号
            </Button>
            <Text className='welcome__tip'>用于账号安全与权益发放（符合 PRD 手机号绑定要求）</Text>
          </View>
        )}

        <Text className='welcome__tourist' onClick={handleTourist}>
          游客体验，先看看
        </Text>
      </View>
    </View>
  )
}
