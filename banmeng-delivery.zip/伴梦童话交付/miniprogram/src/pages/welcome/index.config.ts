export default {
  navigationBarTitleText: '伴梦童话',
  navigationStyle: 'custom',
}
