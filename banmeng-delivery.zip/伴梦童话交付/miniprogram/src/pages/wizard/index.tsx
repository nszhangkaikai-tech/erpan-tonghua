import { useState } from 'react'
import { View, Text, Input, Picker, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import request from '../../utils/request'
import './index.scss'

interface Character {
  name: string
  role: string
  personality: string
}

const DURATION_LABELS = ['短篇', '中篇', '长篇']
const DURATION_VALUES = ['short', 'medium', 'long']

export default function Wizard() {
  const [theme, setTheme] = useState('')
  const [educationalGoal, setEducationalGoal] = useState('')
  const [scene, setScene] = useState('')
  const [characters, setCharacters] = useState<Character[]>([
    { name: '', role: '', personality: '' },
  ])
  const [durationIdx, setDurationIdx] = useState(0)
  const [age, setAge] = useState('4')
  const [submitting, setSubmitting] = useState(false)

  const updateChar = (idx: number, key: keyof Character, value: string) => {
    setCharacters((prev) =>
      prev.map((c, i) => (i === idx ? { ...c, [key]: value } : c)),
    )
  }

  const addChar = () =>
    setCharacters((prev) => [...prev, { name: '', role: '', personality: '' }])
  const removeChar = (idx: number) =>
    setCharacters((prev) => (prev.length > 1 ? prev.filter((_, i) => i !== idx) : prev))

  const handleSubmit = async () => {
    if (!theme.trim()) {
      Taro.showToast({ title: '请填写故事主题', icon: 'none' })
      return
    }
    setSubmitting(true)
    Taro.showLoading({ title: 'StepFun 正在创作…', mask: true })
    try {
      const result = await request({
        url: '/api/story/generate-text',
        method: 'POST',
        data: {
          theme: theme.trim(),
          educationalGoal: educationalGoal.trim(),
          scene: scene.trim(),
          mainCharacters: characters
            .filter((c) => c.name.trim())
            .map((c) => ({
              name: c.name.trim(),
              role: c.role.trim(),
              personality: c.personality.trim(),
            })),
          duration: DURATION_VALUES[durationIdx],
          age: parseInt(age, 10) || 4,
          isRetry: false,
        },
      })
      Taro.hideLoading()
      if (result?.story) {
        // 大对象暂存，预览页读取（替代原型内的内存 state 传递）
        Taro.setStorageSync('bm_draft_story', result.story)
        Taro.navigateTo({ url: '/pages/story/index' })
      } else {
        Taro.showToast({ title: '生成失败', icon: 'none' })
      }
    } catch (e) {
      Taro.hideLoading()
      Taro.showToast({ title: '生成失败，请重试', icon: 'none' })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <View className='wizard'>
      <Text className='wizard__title'>定制专属故事</Text>

      <View className='field'>
        <Text className='field__label'>故事主题</Text>
        <Input
          className='field__input'
          placeholder='如：小熊的第一次露营'
          value={theme}
          onInput={(e) => setTheme(e.detail.value)}
        />
      </View>

      <View className='field'>
        <Text className='field__label'>教育目标</Text>
        <Input
          className='field__input'
          placeholder='如：克服怕黑'
          value={educationalGoal}
          onInput={(e) => setEducationalGoal(e.detail.value)}
        />
      </View>

      <View className='field'>
        <Text className='field__label'>故事场景</Text>
        <Input
          className='field__input'
          placeholder='如：静谧森林'
          value={scene}
          onInput={(e) => setScene(e.detail.value)}
        />
      </View>

      <View className='field'>
        <Text className='field__label'>主角</Text>
        {characters.map((c, idx) => (
          <View className='char' key={idx}>
            <Input
              className='field__input'
              placeholder='姓名'
              value={c.name}
              onInput={(e) => updateChar(idx, 'name', e.detail.value)}
            />
            <Input
              className='field__input'
              placeholder='角色'
              value={c.role}
              onInput={(e) => updateChar(idx, 'role', e.detail.value)}
            />
            <Input
              className='field__input'
              placeholder='性格'
              value={c.personality}
              onInput={(e) => updateChar(idx, 'personality', e.detail.value)}
            />
            {characters.length > 1 && (
              <Text className='char__del' onClick={() => removeChar(idx)}>
                删除
              </Text>
            )}
          </View>
        ))}
        <Text className='field__add' onClick={addChar}>
          + 添加主角
        </Text>
      </View>

      <View className='field'>
        <Text className='field__label'>时长</Text>
        <Picker
          mode='selector'
          range={DURATION_LABELS}
          value={durationIdx}
          onChange={(e) => setDurationIdx(Number(e.detail.value))}
        >
          <View className='field__picker'>{DURATION_LABELS[durationIdx]}</View>
        </Picker>
      </View>

      <View className='field'>
        <Text className='field__label'>孩子年龄</Text>
        <Input
          className='field__input'
          type='number'
          placeholder='4'
          value={age}
          onInput={(e) => setAge(e.detail.value)}
        />
      </View>

      <Button
        className='wizard__submit'
        loading={submitting}
        disabled={submitting}
        onClick={handleSubmit}
      >
        生成故事
      </Button>
    </View>
  )
}
