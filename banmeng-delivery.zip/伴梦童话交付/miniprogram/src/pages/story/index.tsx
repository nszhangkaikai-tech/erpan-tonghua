import { useState, useRef, useEffect } from 'react'
import { View, Text, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import request, { API_BASE } from '../../utils/request'
import './index.scss'

interface Chapter {
  title?: string
  text?: string
  audioUrl?: string
}

interface Story {
  title?: string
  abstract?: string
  chapters?: Chapter[]
  [key: string]: any
}

export default function Story() {
  const [story, setStory] = useState<Story | null>(null)
  const [audioReady, setAudioReady] = useState(false)
  const [synthesizing, setSynthesizing] = useState(false)
  const [playingIdx, setPlayingIdx] = useState(-1)
  const audioCtxRef = useRef<any>(null)

  useEffect(() => {
    const draft = Taro.getStorageSync('bm_draft_story')
    if (draft) setStory(draft)
    return () => {
      if (audioCtxRef.current) audioCtxRef.current.destroy()
    }
  }, [])

  // 合成配音：替换原型 <audio> 为 Taro.createInnerAudioContext
  const handleSynthesize = async () => {
    if (!story) return
    setSynthesizing(true)
    Taro.showLoading({ title: 'StepFun 合成配音中…', mask: true })
    try {
      const result = await request({
        url: '/api/story/generate-audio',
        method: 'POST',
        data: {
          story,
          voiceId: 'voice_default_mom',
          voiceMode: 'single',
          theme: story.theme,
          educationalGoal: story.educationalGoal,
          scene: story.scene,
          mainCharacterName: story.mainCharacterName,
          duration: story.duration,
          targetAge: story.targetAge,
        },
      })
      Taro.hideLoading()
      if (result?.savedStory) {
        setStory(result.savedStory)
        Taro.setStorageSync('bm_draft_story', result.savedStory)
        setAudioReady(true)
      } else {
        Taro.showToast({ title: '合成失败', icon: 'none' })
      }
    } catch (e) {
      Taro.hideLoading()
      Taro.showToast({ title: '合成失败，请重试', icon: 'none' })
    } finally {
      setSynthesizing(false)
    }
  }

  const playChapter = (idx: number, chapter: Chapter) => {
    if (!chapter.audioUrl) {
      Taro.showToast({ title: '演示模式：当前未生成音频', icon: 'none' })
      return
    }
    if (audioCtxRef.current) audioCtxRef.current.destroy()
    const ctx = Taro.createInnerAudioContext()
    ctx.src = API_BASE + chapter.audioUrl
    ctx.onPlay(() => setPlayingIdx(idx))
    ctx.onPause(() => setPlayingIdx(-1))
    ctx.onEnded(() => setPlayingIdx(-1))
    ctx.onError(() => {
      setPlayingIdx(-1)
      Taro.showToast({ title: '播放失败', icon: 'none' })
    })
    ctx.play()
    audioCtxRef.current = ctx
  }

  if (!story) {
    return (
      <View className='story story--empty'>
        <Text>暂无故事，请先去定制。</Text>
      </View>
    )
  }

  return (
    <View className='story'>
      <Text className='story__title'>{story.title}</Text>
      {story.abstract && <Text className='story__abstract'>{story.abstract}</Text>}

      <View className='story__chapters'>
        {(story.chapters || []).map((ch, idx) => (
          <View className='chapter' key={idx}>
            <View className='chapter__head'>
              <Text className='chapter__title'>{ch.title || `第 ${idx + 1} 章`}</Text>
              <Text
                className='chapter__play'
                onClick={() => playChapter(idx, ch)}
              >
                {playingIdx === idx ? '暂停' : ch.audioUrl ? '播放' : '试听'}
              </Text>
            </View>
            <Text className='chapter__text'>{ch.text}</Text>
          </View>
        ))}
      </View>

      <Button
        className='story__synth'
        loading={synthesizing}
        disabled={synthesizing || audioReady}
        onClick={handleSynthesize}
      >
        {audioReady ? '已合成配音' : '合成配音'}
      </Button>
    </View>
  )
}
