export default {
  navigationBarTitleText: '故事预览',
}
