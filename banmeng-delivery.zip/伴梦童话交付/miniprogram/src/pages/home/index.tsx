import { useState, useEffect } from 'react'
import { View, Text, Button } from '@tarojs/components'
import Taro from '@tarojs/taro'
import request from '../../utils/request'
import './index.scss'

interface DBState {
  userStories?: any[]
  notifications?: any[]
  voiceClones?: any[]
  templates?: any[]
  [key: string]: any
}

export default function Home() {
  const [db, setDb] = useState<DBState | null>(null)
  const [loading, setLoading] = useState(true)

  const loadDb = async () => {
    try {
      const data = await request<DBState>({ url: '/api/db' })
      setDb(data)
    } catch (e) {
      Taro.showToast({ title: '加载失败', icon: 'none' })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadDb()
  }, [])

  const goStudio = () => {
    Taro.navigateTo({ url: '/pages/wizard/index' })
  }

  return (
    <View className='home'>
      <View className='home__header'>
        <Text className='home__title'>伴梦童话</Text>
        <Text className='home__subtitle'>用孩子的声音，讲专属的晚安故事</Text>
      </View>

      {loading ? (
        <View className='home__loading'>
          <Text>正在读取云端数据…</Text>
        </View>
      ) : (
        <View className='home__grid'>
          <View className='stat-card'>
            <Text className='stat-card__num'>{db?.userStories?.length ?? 0}</Text>
            <Text className='stat-card__label'>我的故事</Text>
          </View>
          <View className='stat-card'>
            <Text className='stat-card__num'>{db?.templates?.length ?? 0}</Text>
            <Text className='stat-card__label'>故事模板</Text>
          </View>
          <View className='stat-card'>
            <Text className='stat-card__num'>{db?.voiceClones?.length ?? 0}</Text>
            <Text className='stat-card__label'>声音克隆</Text>
          </View>
          <View className='stat-card'>
            <Text className='stat-card__num'>{db?.notifications?.length ?? 0}</Text>
            <Text className='stat-card__label'>通知</Text>
          </View>
        </View>
      )}

      <Button className='home__cta' onClick={goStudio}>
        开始创作故事
      </Button>
    </View>
  )
}
