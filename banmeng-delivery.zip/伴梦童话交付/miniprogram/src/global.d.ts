/// <reference types="@tarojs/taro" />

declare module '*.png'
declare module '*.gif'
declare module '*.jpg'
declare module '*.jpeg'
declare module '*.svg'
declare module '*.scss' {
  const content: { [className: string]: string }
  export default content
}
declare module '*.css'
declare module '*.less'
declare module '*.sass'
