// 伴梦童话 · 行为集成测试（通过公共 HTTP 接口验证，不 mock 内部实现）
// 运行方式：先 `npm run dev` 起服务（端口 3000），再 `node --test test/`
import { test } from "node:test";
import assert from "node:assert/strict";

const BASE = process.env.BASE_URL || "http://localhost:3000";

async function api(path, opts = {}) {
  const res = await fetch(BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* 非 JSON */ }
  return { status: res.status, json, text };
}

// 行为 1：系统状态接口健康，且 Gemini 已彻底移除、StepFun 统计就位
test("GET /api/db 返回合法结构，apiStats 含 stepfunTextCalls、不含 geminiTextCalls", async () => {
  const { status, json } = await api("/api/db");
  assert.equal(status, 200);
  assert.ok(json, "应返回 JSON 数据库");
  assert.ok(json.apiStats, "应含 apiStats 对象");
  assert.equal(json.apiStats.geminiTextCalls, undefined, "Gemini 字段必须已删除");
  assert.equal(typeof json.apiStats.stepfunTextCalls, "number", "apiStats.stepfunTextCalls 必须存在");
  assert.ok(Array.isArray(json.templates), "templates 应为数组");
  assert.ok(Array.isArray(json.voiceClones), "voiceClones 应为数组");
  assert.ok(Array.isArray(json.userStories), "userStories 应为数组");
  assert.ok(Array.isArray(json.notifications), "notifications 应为数组");
});

// 行为 2：故事文本生成在「无 StepFun key」时走离线兜底仍返回合法故事
// （证明删除 Gemini 兜底分支没有打断生成链路）
test("POST /api/story/generate-text 离线兜底返回合法故事", async () => {
  const payload = {
    theme: "睡前安抚",
    educationalGoal: "克服怕黑恐惧",
    scene: "静谧森林",
    mainCharacters: [{ name: "小熊", role: "勇敢的小熊", personality: "活泼" }],
    duration: "short",
    age: 4,
    isRetry: false,
  };
  const { status, json } = await api("/api/story/generate-text", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  assert.equal(status, 200, "生成接口应返回 200");
  assert.ok(json, "应返回故事对象");
  assert.equal(typeof json.story?.title, "string", "故事应有标题");
  assert.ok(Array.isArray(json.story?.chapters) && json.story.chapters.length > 0, "故事应有章节");
  assert.ok(json.story.chapters.every((c) => c.title && c.text), "每章应有标题与正文");
});

// 行为 3：声音克隆返回克隆记录（响应结构：{ success, voice:{ id, name, ... } }）
test("POST /api/voice/clone 返回克隆记录", async () => {
  const { status, json } = await api("/api/voice/clone", {
    method: "POST",
    body: JSON.stringify({ name: "妈妈的声音", speakerType: "mother", recordDuration: 12 }),
  });
  assert.equal(status, 200);
  assert.ok(json?.voice?.id || json?.voice?.voiceId, "应返回克隆 voice.id/voiceId");
  assert.equal(json?.voice?.name, "妈妈的声音");
});

// 行为 4：激活码兑换接口正常响应（不 500）
test("POST /api/cdkey/redeem 正常响应", async () => {
  const { status } = await api("/api/cdkey/redeem", {
    method: "POST",
    body: JSON.stringify({ code: "TESTCODE123" }),
  });
  assert.ok(status === 200 || status === 400, "应返回 200 或 400（无效码），不应 500");
});

// 行为 5：邀请绑定接口正常响应
test("POST /api/referral/bind 正常响应", async () => {
  const { status } = await api("/api/referral/bind", {
    method: "POST",
    body: JSON.stringify({ code: "INVITE_TEST" }),
  });
  assert.ok(status === 200 || status === 400, "应返回 200 或 400，不应 500");
});

// 行为 6：通知「全部已读」接口正常响应
test("POST /api/notifications/read-all 正常响应", async () => {
  const { status } = await api("/api/notifications/read-all", { method: "POST" });
  assert.equal(status, 200);
});

// 行为 7：模拟 StepFun 调用后，apiStats.stepfunTextCalls 自增
test("POST /api/admin/simulate-api-call {type:'stepfun'} 使 stepfunTextCalls 自增", async () => {
  const before = (await api("/api/db")).json.apiStats.stepfunTextCalls;
  const sim = await api("/api/admin/simulate-api-call", {
    method: "POST",
    body: JSON.stringify({ type: "stepfun" }),
  });
  assert.equal(sim.status, 200);
  const after = (await api("/api/db")).json.apiStats.stepfunTextCalls;
  assert.ok(after > before, `stepfunTextCalls 应自增（前 ${before} → 后 ${after}）`);
});

// 行为 8：根路径返回 HTML（前端入口可访问）
test("GET / 返回 HTML 页面", async () => {
  const res = await fetch(BASE + "/");
  const text = await res.text();
  assert.ok(res.status === 200);
  assert.ok(text.toLowerCase().includes("<!doctype html") || text.includes("<html"), "应返回 HTML");
});
