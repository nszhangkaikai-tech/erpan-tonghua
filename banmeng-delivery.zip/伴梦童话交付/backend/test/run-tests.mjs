// 测试编排脚本：拉起 server（无 STEPFUN_API_KEY → 离线兜底）→ 等待就绪 → 跑 node --test → 关闭服务
// 服务日志同时落盘到 /tmp/server.log，便于崩溃取证
import { spawn } from "node:child_process";
import { setTimeout as sleep } from "node:timers/promises";
import { openSync, writeSync, closeSync, existsSync, renameSync, rmSync } from "node:fs";
import { join } from "node:path";

const PORT = 3000;
const BASE = `http://localhost:${PORT}`;
const ROOT = process.cwd();
const DATA_FILE = join(ROOT, "src", "data.json");
const DATA_BACKUP = join(ROOT, "src", "data.json.testbak");
const LOG = openSync("/tmp/server.log", "w");

// 隔离测试数据：备份现有 data.json，让服务从 INITIAL_DB_STATE 干净启动；结束后还原
let restoredData = false;
if (existsSync(DATA_FILE)) {
  renameSync(DATA_FILE, DATA_BACKUP);
}

function logServer(fd, label, d) {
  writeSync(fd, `[${label}] ${d}`);
}

const server = spawn("npx", ["tsx", "server.ts"], {
  cwd: ROOT,
  env: { ...process.env, STEPFUN_API_KEY: "", NODE_ENV: "development" },
  stdio: ["ignore", "pipe", "pipe"],
  detached: true, // 成为独立进程组组长，便于整组回收，避免 npx→tsx→node 孙进程泄漏占用端口
});
server.stdout.on("data", (d) => { process.stdout.write(`[server] ${d}`); logServer(LOG, "OUT", d); });
server.stderr.on("data", (d) => { process.stderr.write(`[server:err] ${d}`); logServer(LOG, "ERR", d); });
server.on("exit", (code, signal) => {
  logServer(LOG, "EXIT", `code=${code} signal=${signal}\n`);
  process.stderr.write(`\n[runner] server exited code=${code} signal=${signal}\n`);
});

async function waitReady(timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(BASE + "/api/db");
      if (res.status === 200) return true;
    } catch {
      // 还没起来，继续等
    }
    await sleep(400);
  }
  throw new Error("服务在超时时间内未就绪");
}

async function runTests() {
  return new Promise((resolve) => {
    const t = spawn("node", ["--test", "test/smoke.test.mjs"], {
      cwd: ROOT,
      stdio: "inherit",
    });
    t.on("close", (code) => resolve(code ?? 1));
  });
}

let exitCode = 1;
try {
  console.log("⏳ 等待服务就绪 ...");
  await waitReady();
  console.log("✅ 服务就绪，开始跑行为测试\n");
  exitCode = await runTests();
} catch (e) {
  console.error("❌ 编排失败:", e.message);
  exitCode = 1;
} finally {
  // 整组回收：detached 后 server.pid 为进程组组长，负向 pid 表示向整组发信号
  try { process.kill(-server.pid, "SIGTERM"); } catch {}
  await sleep(300);
  try { process.kill(-server.pid, "SIGKILL"); } catch {}
  closeSync(LOG);
  // 还原开发数据：删除测试生成的 data.json，恢复备份（若存在）
  try {
    if (existsSync(DATA_FILE)) rmSync(DATA_FILE);
    if (existsSync(DATA_BACKUP)) {
      renameSync(DATA_BACKUP, DATA_FILE);
      restoredData = true;
    }
  } catch (e) {
    console.error("[runner] 还原 data.json 失败:", e.message);
  }
  console.log(`\n🔚 测试退出码: ${exitCode}${restoredData ? "（已还原 src/data.json）" : ""}`);
  process.exit(exitCode);
}
