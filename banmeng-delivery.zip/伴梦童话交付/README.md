# 伴梦童话 · 交付包

亲子定制故事小程序「伴梦童话」的完整源码 + 编译产物 + 后端服务。

> 本包按"先打样"路径落地：已用 **Taro v4.2.1** 把核心业务流（微信登录闸 → 首页/故事屋 → 故事向导 → 章节播放）做成真实可导入微信开发者工具的小程序，并配 Node/Express 后端（已全量移除 Gemini，模型统一走 StepFun 阶跃星辰）。

## 目录结构
```
伴梦童话交付/
├── miniprogram/        # 微信小程序（Taro 工程）
│   ├── dist/           # ★ 已编译产物，直接导入微信开发者工具
│   ├── src/            # 源码（pages / utils / app）
│   ├── config/         # Taro 编译配置
│   ├── project.config.json   # appid 已填真实 wx268d1063ab9d6f2f
│   ├── package.json / tsconfig.json / babel.config.js
└── backend/            # 后端服务（Node + Express，端口 3000）
    ├── server.ts       # Express 入口
    ├── src/            # 业务模块 + data.json 持久化
    ├── test/           # TDD 行为测试（node --test）
    ├── README.md
    └── package.json
```

## 一、小程序（用微信开发者工具打开）
1. 打开**微信开发者工具** → 导入项目 → 目录选 `伴梦童话交付/miniprogram/dist`
2. AppID 已预填 `wx268d1063ab9d6f2f`（请确认你本地开发者工具已登录该 AppID 对应的账号）
3. 编译后进入「欢迎页」：
   - 点 **游客体验** → 直接进首页预览（无需后端也可看 UI）
   - 点 **微信一键登录 + 手机号** → 需后端运行且 `urlCheck` 已关，才可真机跑通 `Taro.login` 与 `getPhoneNumber`
4. 改源码后重新编译：`cd miniprogram && npm install && npm run build:weapp`

## 二、后端（本机起服务，端口 3000）
```bash
cd backend
npm install
cp .env.example .env.local      # 填入 STEPFUN_API_KEY（不填则离线兜底）
npm run dev                     # http://localhost:3000
npm test                        # 跑 8 项行为测试（TDD，自动起停服务、隔离数据）
```
> 小程序与后端联调：确认 `src/utils/request.ts` 的 `API_BASE` 指向你本机后端地址
> （默认 `http://localhost:3000`，真机调试需改成电脑局域网 IP，并在小程序后台配置 request 合法域名）。

## 三、已完成 vs 待补
**已完成（可演示）**
- ✅ 微信登录闸 + 游客体验 fallback
- ✅ 首页/故事屋/我的 三标签 tabBar
- ✅ 故事向导（主题/教育目标/场景/主角/时长/年龄）
- ✅ 章节展示 + 逐章语音播放（`createInnerAudioContext`）
- ✅ 后端 8 项 TDD 全绿（结构/离线兜底/声音克隆/激活码/邀请/通知/StepFun 计数）

**待补（下一阶段）**
- ⬜ 声音复刻录音页（`Taro.getRecorderManager`）
- ⬜ 故事宝库 / 通知中心 / 兑换激活码 / 邀请 / 关于页（my 页当前占位）
- ⬜ 封面生成（step-image-edit-2）
- ⬜ `wx.login` 后端会话兑换端点（闭环真登录，需阶段3 后端或云函数）
- ⬜ 视觉定调（中性灰 token、清理散落 emoji）
- ⬜ 部署迁移（CloudBase 云数据库/存储）
